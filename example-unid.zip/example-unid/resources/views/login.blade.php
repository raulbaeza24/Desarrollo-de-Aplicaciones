<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
    <title>Login</title>
</head>
<body>

    
<header>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <h1>Inicio de Sesion</h1>
      
       
    </div>

      <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <a class="navbar-brand" href="#">Inserte el tipo de usuario con el que desee iniciar sesion: </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="collapsibleNavbar">
         
        </div>
      </nav>
</header>
    
<main class="container">
 
    
<button type="button" class="btn btn-dark">Entrar como Administrador</button>
<button type="button" class="btn btn-dark">Entrar como Microempresas</button>
<button type="button" class="btn btn-dark">Entrar como Viviendas</button>
<button type="button" class="btn btn-dark">Entrar como Trabajador</button>







    <div class="mb-3 row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
          <input type="text" readonly class="form-control-plaintext" id="staticEmail" value="email@example.com">
        </div>
      </div>
      <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" id="inputPassword">
        </div>
      </div>


</main>

<footer>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <p>Footer</p>
        <h3>@yield('numeroPagina')</h3>
      </div>
</footer>

</body>
</html>