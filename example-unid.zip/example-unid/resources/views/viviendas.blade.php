@extends('admin') 

@section('paginaActual') 
    <h2>Viviendas</h2> 
    <h3>Esta es la página CRUD de las Viviendas </h3>
@endsection


@section('framework')
     <img src="" alt="">
     <h1 class='flutter'></h1>
@endsection