@extends('admin')

@section('paginaActual')
    Pagina de Microempresas.
    <h3>Esta es la página CRUD de las Microempresas </h3>
@endsection
 

@section('numeroPagina')
     <h4>pagina 1 productos</h4>
@endsection

@section('framework')
     <h4>REACT NATIVE</h4>
@endsection