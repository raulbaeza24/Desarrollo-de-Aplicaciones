

<?php $__env->startSection('paginaActual'); ?>
    Pagina de Microempresas.
    <h3>Esta es la página CRUD de las Microempresas </h3>
<?php $__env->stopSection(); ?>
 

<?php $__env->startSection('numeroPagina'); ?>
     <h4>pagina 1 productos</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('framework'); ?>
     <h4>REACT NATIVE</h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/microempresas.blade.php ENDPATH**/ ?>