

<?php $__env->startSection('paginaActual'); ?>
    Pagina de PRODUCTOS.
    <h3>aqui se describiran todos los productos</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenidoPrincipal'); ?>
     <p>ESTA ES LA PARTE PRINCIPAL DE LA PAGINA DE PRODUCTOS</p>
     <h4>lista de productos</h4>

     <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
          <div class="card" style="width: 18rem;">
               <img src="..." class="card-img-top" alt="...">
               <div class="card-body">
                 <h5 class="card-title"><?php echo e($producto->Nombre); ?></h5>
                 <p class="card-text"><?php echo e($producto->Descripcion); ?></p>
                 <a href="#" class="btn btn-primary">Go somewhere</a>
               </div>
             </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <h3></h3>
         
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('numeroPagina'); ?>
     <h4>pagina 1 productos</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('framework'); ?>
     <h4>REACT NATIVE</h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/productos.blade.php ENDPATH**/ ?>