<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
    <title>Página Administrador</title>
</head>
<body>

    
<header>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <h1>Bienvenido <?php echo $__env->yieldContent('framework'); ?> Administrador</h1>
        <p>PAGINA ADMINISTRADOR</p>
        <h2><?php echo $__env->yieldContent('paginaActual'); ?></h2>
    </div>

      <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">Agregar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Eliminar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Editar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Leer Información</a>
            </li>
          </ul>
        </div>
      </nav>
</header>
    
<main class="container">
  <?php echo $__env->yieldContent('contenidoPrincipal'); ?>
  <form>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputEmail4">Nombre</label>
        <input type="email" class="form-control" id="inputEmail4">
      </div>
      <div class="form-group col-md-6">
        <label for="inputPassword4">Apellido</label>
        <input type="password" class="form-control" id="inputPassword4">
      </div>
    </div>
    <div class="form-group">
      <label for="inputAddress">Sexo</label>
      <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
    </div>
    <div class="form-group">
      <label for="inputAddress2">Cargo</label>
      <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
    </div>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputCity">City</label>
        <input type="text" class="form-control" id="inputCity">
      </div>
      <div class="form-group col-md-4">
        <label for="inputState">State</label>
        <select id="inputState" class="form-control">
          <option selected>Choose...</option>
          <option>...</option>
        </select>
      </div>
      <div class="form-group col-md-2">
        <label for="inputZip">Zip</label>
        <input type="text" class="form-control" id="inputZip">
      </div>
    </div>
    <div class="form-group">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck">
        <label class="form-check-label" for="gridCheck">
          Check me out
        </label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Sign in</button>
  </form> 
</main>

<footer>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <p>Footer</p>
        <h3><?php echo $__env->yieldContent('numeroPagina'); ?></h3>
      </div>
</footer>

</body>
</html><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/admin.blade.php ENDPATH**/ ?>