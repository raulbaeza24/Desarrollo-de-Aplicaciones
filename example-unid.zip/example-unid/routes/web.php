<?php

use Illuminate\Support\Facades\Route;
/* use App\Http\Controllers\ProductosControllerCRUD; */

/* use App\Http\Controllers\ServiciosController; */


Route::get('/', function () {
    return view('welcome');
});
/*
Route::get('/saludo', function () {
    return view('alumnos');
});*/
//---------------------------------------------
Route::view('/', 'welcome');
Route::view('/saludo', 'admin')->name('saludoname');


Route::view('/admin', 'admin')->name('admin');

Route::view('/microempresas', 'microempresas')->name('microempresas');
//Route::get('/productos', ProductosController::class)->name('productos');

//Route::get('/microempresas', [ProductosControllerCRUD::class, 'index'])->name('microempresas');


//Route::view('/servicios', 'servicios')->name('servicios');
Route::view('/trabajador', 'trabajador')->name('trabajador');


//Route::get('/alumnos', [AlumnosController::class, 'index'])->name('students');
// Route::get('/servicios', [ServiciosController::class, 'index'])->name('servicios');
Route::view('/viviendas', 'viviendas')->name('viviendas');


Route::view('/login', 'login')->name('login');
