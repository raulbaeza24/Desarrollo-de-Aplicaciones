<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;


class SessionsController extends Controller {



   public function create(){

        return view('login');
    }

    public function store(){

     //auth()->attempt(request(['email', 'password'])) ;
     //$user = User::create(request(['email', 'password']));

     //auth()->login($user);
     return redirect()->to('adminmain');
     }
    
     
   }

 

 //public function destroy(){

  //auth()->logout();

  //return redirect()->to('adminmain');
 //}

 