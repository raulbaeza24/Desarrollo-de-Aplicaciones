<?php

namespace App\Http\Controllers;

use App\Models\Createadmin;
use GuzzleHttp\Promise\Create;
use Illuminate\Http\Request;

class CreateadminController extends Controller
{
    

  public function create(){

    return view('createadmin');
}

public function store() {
  $productos =Createadmin::create(request(['Nombre', 'Descripcion']));

  auth()->login($productos);
return redirect()->to('admin');
}


}



