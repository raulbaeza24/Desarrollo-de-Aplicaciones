<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    <title>Login</title>
</head>
<body style="background-color: #023047">

    
<header>
  <div class="jumbotron text-center" style="background-color: #8ecae6">
    <font color="black">
        <h1>Inicio de Sesión</h1>
      </font>
    </div>
  </header>
    
<main class="container">

  <!-- SECCIÓN DE BOTONES DE SELECCIÓN DE TIPO DE USUARIO CANCELADO

  <h1>Inserte el tipo de usuario con el que desee iniciar sesion: </h1>
  <div class="form-row">
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Administrador</button>
    </div>
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Microempresas</button>
    </div>
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Viviendas</button>
    </div>
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Trabajador</button>
    </div>
  </div>
-->

<section class="form" class="form-group col-md-center">
  <form method="POST">
  @csrf
 
  <div class="row mb-3">
    <font color="white">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Correo Electrónico:  </label>
  </font>
    <div class="col-sm-10">

      <input type="email" class="form-control" id="email" placeholder="Example@hotmail.com" name="email">
     
    </div>
  </div>
  <div class="row mb-3">
    <font color="white">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Contraseña: </label>
   </font>
    <div class="col-sm-10">

      <input type="password" class="form-control" id="password" placeholder="Contraseña" name="password">
   
    </div>
  
  </div>
 
  @error('message')
  <p>ERROR</p>
  @enderror


  <div class="form-group col-md-center">
    <button type="submit" class="btn btn-success mx-auto d-block">Iniciar Sesión</button>

  </div>

</form>

</section>

</main>


<footer class="text-center text-white fixed-bottom" style="background-color: #6bb5ff">
  <div class="container p-4">
    <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
          
      <a class="btn btn-success" href="{{route('registro')}}">Registrate</a>
       </div>

  </div>
</footer>
</body>
</html>