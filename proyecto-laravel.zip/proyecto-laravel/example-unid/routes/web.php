<?php

use Illuminate\Support\Facades\Route;

//USE PARA REGISTRO E INICIO DE SESION
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\SessionsController;

//USE PARA CRUDS CON BD
use App\Http\Controllers\ProductosControllerCRUD;
use App\Http\Controllers\CreateadminController;

//use App\Http\Controllers\ServiciosController; 

Route::get('/', function () {
    return view('welcome');
});

// RUTAS DEL WELCOME
Route::view('/', 'welcome');

//RUTAS DE LOGIN
 Route::view('/login', 'login')->name('login');
 Route::get('/login', [SessionsController::class, 'create'])->name('login');
 Route::post('/login', [SessionsController::class, 'store'])->name('login.store');

//RUTAS DE REGISTRO DE SESIONES
 Route::view('/registro', 'registro')->name('registro');
 Route::get('/registro', [RegisterController::class, 'create'])->name('registro');
 Route::post('/registro', [RegisterController::class, 'store'])->name('registro.store');

//RUTAS DEL ADMIN
Route::view('/adminmain', 'adminmain')->name('adminmain');
Route::view('/admin', 'admin')->name('admin');
Route::view('/adminperfil', 'adminperfil')->name('adminperfil');
Route::view('/adminuser', 'adminuser')->name('adminuser');
Route::get('/admin', [ProductosControllerCRUD::class, 'index'])->name('admin');

//RUTAS DE MICROEMPRESA
Route::view('/microempresas', 'microempresas')->name('microempresas');
Route::view('/microempresasperfil', 'microempresasperfil')->name('microempresasperfil');

//RUTAS DEL VIVIENDAS
Route::view('/viviendas', 'viviendas')->name('viviendas');
Route::view('/viviendasperfil', 'viviendasperfil')->name('viviendasperfil');

//RUTAS DEL TRABAJADOR
Route::view('/trabajador', 'trabajador')->name('trabajador');
Route::view('/trabajadorperfil', 'trabajadorperfil')->name('trabajadorperfil');


//RUTAS DE LOS CRUD DE PRODUCTOS (PUBLICACIONES)
Route::get('/productos', [ProductosControllerCRUD::class, 'index'])->name('productos');
Route::post('/productos', [ProductosControllerCRUD::class, 'store'])->name('productos.store');

//CREATE DE ADMIN
Route::view('/createadmin', 'createadmin')->name('createadmin');
Route::get('/createadmin', [CreateadminController::class, 'index'])->name('createadmin');
Route::post('/createadmin', [CreateadminController::class, 'store'])->name('createadmin.store');




//Route::get('/alumnos', [AlumnosController::class, 'index'])->name('students');
//Route::get('/servicios', [ServiciosController::class, 'index'])->name('servicios');
//Route::view('/servicios', 'servicios')->name('servicios');
//Route::get('/productos', [ProductosController::class])->name('productos');