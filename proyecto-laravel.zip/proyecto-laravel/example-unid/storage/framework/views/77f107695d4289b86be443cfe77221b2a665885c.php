<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    <title>Create Admin</title>
</head>
<body style="background-color: #f4ff43">

    
<header>
    <div class="jumbotron text-center" style="background-color: #ef5ca6">
      <font color="white">
        <h1>CREAR PUBLICACION DE Administrador</h1>
      </font>
    </div>
  </header>
    
<main class="container">

  <!-- SECCIÓN DE BOTONES DE SELECCIÓN DE TIPO DE USUARIO CANCELADO

  <h1>Inserte el tipo de usuario con el que desee iniciar sesion: </h1>
  <div class="form-row">
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Administrador</button>
    </div>
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Microempresas</button>
    </div>
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Viviendas</button>
    </div>
    <div class="form-group col-md-3">
<button type="button" class="btn btn-success">Entrar como Trabajador</button>
    </div>
  </div>
-->

<section class="form" class="form-group col-md-center">
<form method="POST">
  <?php echo csrf_field(); ?>
 
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Nombre de Publicacion:  </label>
    <div class="col-sm-10">
      <input type="Nombre" class="form-control" id="Nombre" placeholder="Nombre" name="Nombre">
     
    </div>
  </div>

  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Descripcion:  </label>
    <div class="col-sm-10">
      <input type="Descripcion" class="form-control" id="Descripcion" placeholder="Descripcion" name="Descripcion">
     
    </div>
  </div>

  


  
  

  <div class="form-group col-md-center">
  
  <button type="submit" class="btn btn-primary mx-auto d-block">Crear</button>
  </div>
</form>
</section>

</main>


<footer class="text-center text-white fixed-bottom" style="background-color: #6bb5ff">
  <div class="container p-4">
    <h3>Footer</h3>
  </div>
</footer>
</body>
</html><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/createadmin.blade.php ENDPATH**/ ?>