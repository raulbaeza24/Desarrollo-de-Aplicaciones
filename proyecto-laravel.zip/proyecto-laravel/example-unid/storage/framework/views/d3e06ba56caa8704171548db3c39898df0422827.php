<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
    <title>Página Vivienda</title>
</head>
<body style="background-color: #f4ff43">

 
<header>
  
  <div class="jumbotron text-center" style="background-color: #ef5ca6">
        <h1>Bienvenido <?php echo $__env->yieldContent('framework'); ?> Vivienda</h1>
        <p>Página "Mi perfil" Vivienda</p>
        <h2><?php echo $__env->yieldContent('paginaActual'); ?></h2>

        <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
          <a class="btn btn-success" href="<?php echo e(route('viviendas')); ?>">Menú Principal</a>
           </div>
   
      <nav class="navbar navbar-expand-sm" style="background-color: #5ff4ab"> 
        <a class="navbar-brand" href="#">¿Qué función desea ejecutar? </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">Agregar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Eliminar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Editar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Leer Información</a>
            </li>
          </ul>
          <button type="button" class="btn" style="background-color: #bd13ec">Imprimir en PDF</button> 
        </div>
      </nav>
    </div>
      
</header>
  
    
<main class="container">
  <?php echo $__env->yieldContent('contenidoPrincipal'); ?>
  <form>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputEmail4">Nombre: </label>
        <input type="nombre" class="form-control" id="nombre">
      </div>
      <div class="form-group col-md-6">
        <label for="inputPassword4">Apellido: </label>
        <input type="apellido" class="form-control" id="apellido">
      </div>
    </div>
    <div class="form-group">
      <label for="inputAddress">Sexo: </label>
        <select class="form-select" id="inlineFormSelectPref">
          <option value="1">Masculino</option>
          <option value="2">Femenino</option>
          <option value="3">Otro</option>
        </select>
     
    </div>
    <div class="form-group">
      <label for="inputAddress2">Cargo: </label>
      <input type="cargo" class="form-control" id="cargo" placeholder="Vivienda">
    </div>
   
    <div class="form-group col-md-center">
      <button type="submit" class="btn mx-auto d-block" style="background-color: #bd13ec">Guardar Cambios</button>
      </div>
  </form> 
</main>


<footer class="text-center text-white fixed-bottom" style="background-color: #6bb5ff">
  <div class="container p-4">
    <h3>Footer</h3>
  </div>
</footer>
</body>
</html><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/viviendasperfil.blade.php ENDPATH**/ ?>