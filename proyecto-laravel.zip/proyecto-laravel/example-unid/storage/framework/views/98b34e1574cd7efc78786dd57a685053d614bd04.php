<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
    <title>Página Administrador</title>
</head>
<body style="background-color: #023047">
  

    
<header>
  
  <div class="jumbotron text-center" style="background-color: #8ecae6">
    <font color="black">
        <h1>Bienvenido <?php echo $__env->yieldContent('framework'); ?> Administrador</h1>
        <p>Página CRUD de Publicaciones Administrador</p>
        <h2><?php echo $__env->yieldContent('paginaActual'); ?></h2>
    </font>

        <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
          
          <a class="btn btn-success" href="<?php echo e(route('adminmain')); ?>">Menú Principal</a>
           </div>
    
          
      <nav class="navbar navbar-expand-sm" style="background-color: black"> 
        <a class="navbar-brand" href="#">¿Qué función desea ejecutar? </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#"><button type="button" class="btn btn-success">Agregar Información</button></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Eliminar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Editar Información</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Leer Información</a>
            </li>
          </ul>
          <button type="button" class="btn btn-success">Imprimir en PDF</button> 
        </div>
      </nav>
    </div>
      
</header>
  
<main class="container">
  <font color="white">
  <h1>Seleccione el tipo de usuario al que desea sobreponer la función seleccionada: </h1>
  </font>


  <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
  <div class="card" style="width: 18rem;">
       <img src="..." class="card-img-top" alt="...">
       <div class="card-body">
         <h5 class="card-title"><?php echo e($producto->Nombre); ?></h5>
         <p class="card-text"><?php echo e($producto->Descripcion); ?></p>
         <a href="#" class="btn btn-primary">Editar</a>
         <a href="#" class="btn btn-danger">Eliminar</a>
       </div>
     </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<h3></h3>
 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="form-row">
    <div class="form-group col-md-4">
      <select class="form-select" id="inlineFormSelectPref">
        <option value="1">Microempresas</option>
        <option value="2">Microempresa 1</option>
        <option value="3">Microempresa 2</option>
      </select>
   
  </div>

  <div class="form-group col-md-4">
    <select class="form-select" id="inlineFormSelectPref">
      <option value="1">Viviendas</option>
      <option value="2">Viviendas 1</option>
      <option value="3">Viviendas 2</option>
    </select>
 
</div>

<div class="form-group col-md-4">
  <select class="form-select" id="inlineFormSelectPref">
    <option value="1">Trabajadores</option>
    <option value="2">Trabajadores 1</option>
    <option value="3">Trabajadores 2</option>
  </select>

</div>
    </div>
  
 
</main>




<footer class="text-center text-white fixed-bottom" style="background-color: #6bb5ff">
  <div class="container p-4">
    <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
          
      <a class="btn btn-success" href="<?php echo e(route('createadmin')); ?>">Crear Publicaciones</a>
       </div>

  </div>
</footer>
  
</body>
</html><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/admin.blade.php ENDPATH**/ ?>