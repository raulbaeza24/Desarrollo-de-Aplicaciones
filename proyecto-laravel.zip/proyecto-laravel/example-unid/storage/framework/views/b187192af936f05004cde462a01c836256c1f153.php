

<?php $__env->startSection('paginaActual'); ?>
    <h2>SERVICIOS!!!</h2> 
    <h4>aqui se describiran todos los servicios</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenidoPrincipal'); ?>
     
   <h2>Lista de servicio</h2>
  
   <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <h3><?php echo e($servicio->title); ?></h3>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('framework'); ?>
     <img src="" alt="">
     <h1 class='flutter'></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-unid\resources\views/servicios.blade.php ENDPATH**/ ?>