 

<?php $__env->startSection('paginaActual'); ?> 
    <h2>Viviendas</h2> 
    <h3>Esta es la página CRUD de las Viviendas </h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenidoPrincipal'); ?>
     
   <h2>Lista de servicio</h2>
  
   <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <h3><?php echo e($servicio->title); ?></h3>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('framework'); ?>
     <img src="" alt="">
     <h1 class='flutter'></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/servicios.blade.php ENDPATH**/ ?>