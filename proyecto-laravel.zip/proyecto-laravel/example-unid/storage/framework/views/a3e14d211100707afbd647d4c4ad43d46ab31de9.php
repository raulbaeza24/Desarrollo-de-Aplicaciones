<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
    <title>Layout Boostrap</title>
</head>
<body>

    
<header>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <h1>My First <?php echo $__env->yieldContent('framework'); ?> 4 Page</h1>
        <p>Resize this responsive page to see the effect!</p>
        <h2><?php echo $__env->yieldContent('paginaActual'); ?></h2>
    </div>

      <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Blog</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
          </ul>
        </div>
      </nav>
</header>
    
<main class="container">
  <?php echo $__env->yieldContent('contenidoPrincipal'); ?>
</main>

<footer>
    <div class="jumbotron text-center" style="margin-bottom:0">
        <p>Footer</p>
        <h3><?php echo $__env->yieldContent('numeroPagina'); ?></h3>
      </div>
</footer>

</body>
</html><?php /**PATH C:\laragon\www\example-unid\resources\views/layout.blade.php ENDPATH**/ ?>