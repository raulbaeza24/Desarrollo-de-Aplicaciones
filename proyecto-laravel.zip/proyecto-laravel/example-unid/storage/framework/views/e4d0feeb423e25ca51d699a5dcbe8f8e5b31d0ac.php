<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
   
    <title>Página Administrador</title>
</head>
<body style="background-color: #f4ff43">

    
<header>

  <div class="jumbotron text-center" style="background-color: #ef5ca6">
    <font color="white">
        <h1>Bienvenido <?php echo $__env->yieldContent('framework'); ?> Administrador</h1>
        <p>PÁGINA PRINCIPAL DEL ADMINISTRADOR</p>
        <h2><?php echo $__env->yieldContent('paginaActual'); ?></h2>
    </font>

        <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
         <a class="btn btn-success" href="<?php echo e(route('adminperfil')); ?>">Mi Perfil</a>
          </div>
        </div>
  
</header>
   
<style>
  .container{

    height: 44vh;
       display: flex;
    justify-content: center;
    align-items: center; 

  }
</style>



<main class="container">   
  <div class="form-row">
    <div class="form-group col-md-center"> 
      <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
        <a class="btn btn-success" href="<?php echo e(route('adminuser')); ?>">Administración de usuarios</a>
         </div>
    </div>
    <div class="form-group col-md-center"> 
      <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
        <a class="btn btn-success" href="<?php echo e(route('admin')); ?>">Administración de publicaciones</a>
         </div>
    </div>

  </div>
</main>


<footer class="text-center text-white fixed-bottom" style="background-color: #6bb5ff">
  <div class="container2 p-4">
    <div class="form-group col-md-center ml-4 text-lg leading-7 font-semibold">
      <a class="btn btn-danger" href="<?php echo e(route('login')); ?>">Cerrar Sesión</a>
       </div>
  </div>
</footer>

</body>
</html><?php /**PATH C:\laragon\www\proyecto-laravel\example-unid\resources\views/adminmain.blade.php ENDPATH**/ ?>